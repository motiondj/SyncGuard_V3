This is a modified version of the original Scalable MPCDI library.

